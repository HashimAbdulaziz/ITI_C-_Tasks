#include "meshostdio.h"
#include "readkey.h"
#include "interactive.h"
#include <vector>


using namespace std;


int main() {

    ClearScreen();

    DrawMenu();
    DrawMenuWithSelection();
    return 0;
}



